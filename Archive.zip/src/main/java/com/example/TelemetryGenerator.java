package com.example;

import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.SimpleSpanProcessor;
import io.opentelemetry.exporter.logging.LoggingSpanExporter;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

import java.util.Random;

@Component
public class TelemetryGenerator {

    private static final Logger logger = LoggerFactory.getLogger(TelemetryGenerator.class);
    private Tracer tracer;
    private final Counter randomActionCounter;
    private final Counter errorCounter;


    public TelemetryGenerator(MeterRegistry registry) {
        this.randomActionCounter = Counter.builder("random.action.count")
                .description("Counts how many random actions were generated")
                .register(registry);
        this.errorCounter = Counter.builder("random.action.errors")
                .description("Counts how many simulated errors occurred")
                .register(registry);
    }


    @PostConstruct
    public void setupOpenTelemetry() {
        LoggingSpanExporter spanExporter = new LoggingSpanExporter();
        OpenTelemetrySdk sdk = OpenTelemetrySdk.builder()
                .setTracerProvider(SdkTracerProvider.builder()
                        .addSpanProcessor(SimpleSpanProcessor.create(spanExporter))
                        .build())
                .buildAndRegisterGlobal();

        this.tracer = sdk.getTracer("random-generator");

        logger.info("OpenTelemetry initialized");
    }

    @Scheduled(fixedRate = 5000)
    public void generateRandomTelemetry() {
        if (tracer == null) return;

        Span span = tracer.spanBuilder("generate-random-span").startSpan();
        Random random = new Random();
        try {
            String action = new String[]{"login", "purchase", "search"}[random.nextInt(3)];
            span.setAttribute("action", action);
            span.setAttribute("user.id", random.nextInt(1000));

            // Simulate error randomly
            boolean simulateError = random.nextDouble() < 0.3;
            if (simulateError) {
                String errorType = new String[]{"TimeoutException", "NullPointerException", "DBConnectionError"}[random.nextInt(3)];
                span.setStatus(io.opentelemetry.api.trace.StatusCode.ERROR, "Simulated error: " + errorType);
                span.setAttribute("error.type", errorType);
                errorCounter.increment();
                logger.error("🚨 Simulated ERROR [{}]: {}", action, errorType);
            } else {
                logger.info("✅ Simulated OK [{}]", action);
            }

            randomActionCounter.increment();

        } finally {
            span.end();
        }
    }

}
