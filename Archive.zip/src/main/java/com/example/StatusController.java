package com.example;

import org.springframework.web.bind.annotation.*;

import java.util.concurrent.atomic.AtomicReference;

@RestController
@RequestMapping("/status")
public class StatusController {

    public enum HealthStatus {
        HEALTHY, DEGRADED, DOWN
    }

    private final AtomicReference<HealthStatus> currentStatus = new AtomicReference<>(HealthStatus.HEALTHY);

    @GetMapping
    public String getStatus() {
        HealthStatus status = currentStatus.get();
        return switch (status) {
            case HEALTHY -> "System is healthy";
            case DEGRADED -> "System is experiencing issues";
            case DOWN -> "System is down";
        };
    }

    @PostMapping("/degrade")
    public String degrade() {
        currentStatus.set(HealthStatus.DEGRADED);
        return "System status set to DEGRADED";
    }

    @PostMapping("/down")
    public String down() {
        currentStatus.set(HealthStatus.DOWN);
        return "System status set to DOWN";
    }

    @PostMapping("/recover")
    public String recover() {
        currentStatus.set(HealthStatus.HEALTHY);
        return "System status set to HEALTHY";
    }
}

